/*
 * Copyright (C) 2023-2023 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <chrono>
#include "syscall_iteration.h"

/* The two next templates enforce recursive compilation and
   generate a large binary with a few code lines whe j is big.
   This is important in order to make PIN process do jitting
   as much as possible and been the main processing done */
template< int j > struct Foo
{
    static int Worker(int x) { return j ^ x ^ Foo< j - 1 >::Worker(x + j); }
};

template<> struct Foo< 0 >
{
    static int Worker(int x) { return x; }
};

void Usage(char** argv)
{
    std::cerr << "Syntax is:";
    std::cerr << "\t" << argv[0] << " <options>\n";
}

int main(int argc, char** argv)
{
    bool mode_statistic = false;

    auto start = myclock::now();

#if defined(TARGET_LINUX) && defined(TARGET_IA32)
    // For some reason 80000 with 32b takes a very long time with pin
    int value = Foo< 30000 >::Worker(rand());
#else
    int value = Foo< 80000 >::Worker(rand());
#endif
    std::cout << "Value returned = " << value << std::endl;

    auto end                     = myclock::now();
    auto time_spent              = std::chrono::duration_cast< std::chrono::microseconds >(end - start);
    unsigned int test_time_usecs = time_spent.count();

    std::cout << "Iteration delay: " << test_time_usecs << " usec\n";

    return 0;
}
