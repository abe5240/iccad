/*
 * Copyright (C) 2008-2021 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

int main()
{
    int x = 8;
    return 0;
}
