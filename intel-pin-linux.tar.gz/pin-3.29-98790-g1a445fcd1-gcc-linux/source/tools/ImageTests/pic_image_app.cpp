/*
 * Copyright (C) 2018-2021 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

// dummy application to be compiled as PIC (position independent code)

#include <iostream>
#include <cstdio>
int main() { printf(""); }
