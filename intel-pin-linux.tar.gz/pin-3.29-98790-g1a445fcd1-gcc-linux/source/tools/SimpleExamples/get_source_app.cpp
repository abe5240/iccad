/*
 * Copyright (C) 2012-2021 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

int main()
{
    int x = 1;
    --x;
    return x;
}
